KIWI OS REAL DESKTOP WALLPAPER

The desktop now loads background.bmp, a real 320x200, 8-bit indexed BMP image.
It is stored in the existing filesystem as BACKGROUND.BMP at disk LBA 40.
The boot code reads the BMP palette into the VGA DAC and copies the image pixels
to the VGA framebuffer. When an app exits, the wallpaper is redrawn from the
loaded image buffer rather than painting the old flat green screen.

The first 16 palette slots are kept compatible with the desktop's VGA UI colors;
the wallpaper itself uses palette indexes 16 through 255.

Rebuild from the project folder with:
    make clean && make && make run
