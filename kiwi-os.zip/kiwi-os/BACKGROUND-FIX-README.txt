KIWI OS BACKGROUND FIX

This patch addresses two problems in the previous wallpaper build:
1. BACKGROUND.BMP is no longer exposed as a clickable desktop/file-list item.
   It remains a real BMP resource stored in the disk image at LBA 40.
2. When an app switches to BIOS text mode, the VGA palette is reset. On app
   return the OS now reloads the BMP palette and pixels before drawing the UI.

Build and test on your Mac:
    make clean && make && make run

The source was patched against the exact previous wallpaper ZIP. The ZIP
contents were checked, but assembly and QEMU boot testing were not available
in the patching environment. Keep a copy of your previous working ZIP.
