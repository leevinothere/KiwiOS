Kiwi OS app metadata integration
================================

Each desktop app now has one metadata record in kernel/app_metadata.inc:
- desktop X/Y position
- app type (1 = application)
- icon bitmap pointer
- zero-terminated display name
- zero-terminated executable filename

Current records:
- Files: icons/files.kic, display name Files, executable FILES.PA
- EDIT: icons/edit.kic, display name EDIT, executable EDIT.PA

The desktop icon renderer reads the icon pointer and position from each record.
The type, name, and executable filename are now stored with the app metadata,
but the current desktop does not yet display the names or use the executable
filename to launch apps. That is a separate next step. Existing click/launch
behavior was not intentionally changed.

The .kic images are embedded into stage2 at assembly time. The existing .bin
and disk image files in this archive are included as reference copies and are
not rebuilt by this edit. Rebuild in a separate extracted folder with `make clean && make`.
NASM and QEMU were not available here, so the updated source has NOT been
assembled or boot-tested. Keep your working version untouched while testing.
