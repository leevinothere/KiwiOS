bits 16
org 0

; Kiwi OS text editor
; Supports selecting any non-.PA file up to 512 bytes.
; Keys: W/S select, Enter edit, arrows move, Backspace delete,
; Enter inserts CR/LF, Ctrl+S saves, Esc returns to file list.

editor:
    ; Keep BIOS keyboard input available to the app.
    cld
    sti
    push ds
    push cs
    pop ds
    xor ax, ax
    mov es, ax
    mov dl, [es:0x0500]
    mov [drive], dl

menu:
    ; Load filesystem directory (sectors 9 and 10) to 0000:9100.
    mov si, dir_dap
    mov ah, 0x42
    mov dl, [drive]
    int 0x13
    jc disk_error

    mov word [file_count], 0
    mov word [selected], 0
    mov si, 0x912F
    mov cx, 16

collect:
    cmp byte [es:si], 0
    je collected
    push cx
    call is_pa                 ; carry set if this entry is a .PA app
    pop cx
    jc collect_next
    mov bx, [file_count]
    shl bx, 1
    mov [entries+bx], si
    inc word [file_count]
collect_next:
    add si, 36
    loop collect

collected:
    jmp list_screen

; Input ES:SI directory entry. CF=1 for filename ending exactly in .PA.
is_pa:
    push ax
    push bx
    push di
    mov di, si
    mov bx, 32
pa_scan:
    cmp byte [es:di], 0
    je pa_no
    cmp byte [es:di], '.'
    je pa_dot
    inc di
    dec bx
    jnz pa_scan
pa_no:
    clc
    jmp pa_done
pa_dot:
    cmp byte [es:di+1], 'P'
    jne pa_no
    cmp byte [es:di+2], 'A'
    jne pa_no
    cmp byte [es:di+3], 0
    jne pa_no
    stc
pa_done:
    pop di
    pop bx
    pop ax
    ret

list_screen:
    mov ax, 0x0003
    int 0x10
    mov si, list_title
    call print_string
    cmp word [file_count], 0
    jne draw_list
    mov si, no_files
    call print_string
    jmp list_keys

draw_list:
    xor bx, bx
draw_entry:
    cmp bx, [file_count]
    jae list_keys
    mov al, ' '
    cmp bx, [selected]
    jne draw_marker
    mov al, '>'
draw_marker:
    call putc
    mov al, ' '
    call putc
    push bx
    shl bx, 1
    mov si, [entries+bx]
    pop bx
    mov cx, 32
draw_name:
    mov al, [es:si]
    test al, al
    jz name_done
    push cx
    push si
    call putc
    pop si
    pop cx
    inc si
    loop draw_name
name_done:
    mov al, 13
    call putc
    mov al, 10
    call putc
    inc bx
    jmp draw_entry

list_keys:
    mov si, list_controls
    call print_string
wait_list_key:
    call read_app_key
    cmp al, 27
    je exit_editor
    cmp al, 'w'
    je move_up
    cmp al, 'W'
    je move_up
    cmp al, 's'
    je move_down
    cmp al, 'S'
    je move_down
    cmp al,'p'
    je exit_editor
    cmp al, 13
    je open_file
    jmp wait_list_key
move_up:
    cmp word [selected], 0
    je list_screen
    dec word [selected]
    jmp list_screen
move_down:
    mov ax, [selected]
    inc ax
    cmp ax, [file_count]
    jae wait_list_key
    mov [selected], ax
    jmp list_screen

open_file:
    cmp word [file_count], 0
    je wait_list_key
    mov bx, [selected]
    shl bx, 1
    mov si, [entries+bx]
    mov [entry_ptr], si

    ; Do not silently truncate files larger than one sector.
    mov ax, [es:si+32]
    cmp ax, 512
    ja file_too_large
    mov [content_size], ax
    mov word [cursor_pos], 0

    ; Read selected file's start sector to 0000:9500.
    mov ax, [es:si+34]
    mov [file_dap+8], ax
    mov si, file_dap
    mov ah, 0x42
    mov dl, [drive]
    int 0x13
    jc disk_error

    ; File data is read to physical 0000:9500.
    mov ax, cs
    mov ds, ax
    xor ax, ax
    mov es, ax
    cld
    call redraw_editor


edit_key:
    ; Read a key using BIOS keyboard services.
    mov ah, 0x00
    int 0x16

    ; Esc returns to the file list.
    cmp al, 27
    je exit_editor

    ; Ctrl+S saves the file.
    cmp al, 19
    je save_file

    ; Backspace deletes the previous character.
    cmp al, 8
    je backspace

    ; Enter inserts a new line.
    cmp al, 13
    je insert_newline

    ; BIOS returns AL=0 for special keys.
    cmp al, 0
    jne maybe_insert

    ; Check the scan code in AH.
    cmp ah, 0x4B
    je cursor_left
    cmp ah, 0x4D
    je cursor_right
    cmp ah, 0x47
    je cursor_home
    cmp ah, 0x4F
    je cursor_end

    jmp edit_key

maybe_insert:
    ; Ignore control characters.
    cmp al, 32
    jb edit_key

    ; Maximum file size: 512 bytes.
    cmp word [content_size], 512
    jae edit_key

    call insert_character
    call redraw_editor
    jmp edit_key

cursor_left:
    cmp word [cursor_pos], 0
    je edit_key
    dec word [cursor_pos]
    call redraw_editor
    jmp edit_key
cursor_right:
    mov ax, [cursor_pos]
    cmp ax, [content_size]
    jae edit_key
    inc word [cursor_pos]
    call redraw_editor
    jmp edit_key
cursor_home:
    mov word [cursor_pos], 0
    call redraw_editor
    jmp edit_key
cursor_end:
    mov ax, [content_size]
    mov [cursor_pos], ax
    call redraw_editor
    jmp edit_key

backspace:
    cmp word [cursor_pos], 0
    je edit_key
    dec word [cursor_pos]
    mov bx, [cursor_pos]
    mov si, 0x9500
    add si, bx
    mov di, si
    inc si
    mov cx, [content_size]
    sub cx, bx
    dec cx
    jcxz backspace_done
    push ds
    push es
    pop ds                    ; DS=0 so source buffer is physical 0000:9500
    cld
    rep movsb
    pop ds
backspace_done:
    dec word [content_size]
    call redraw_editor
    jmp edit_key

insert_newline:
    cmp word [content_size], 510
    ja edit_key
    ; Insert CR then LF at cursor position by shifting tail twice.
    mov al, 13
    call insert_character
    mov al, 10
    call insert_character
    call redraw_editor
    jmp edit_key

; Insert AL at cursor_pos, shifting existing bytes right.
insert_character:
    mov [temp_char], al
    push bx
    push cx
    push si
    push di
    cld
    mov bx, [cursor_pos]
    mov cx, [content_size]
    sub cx, bx
    jcxz insert_store
    mov si, 0x9500
    add si, [content_size]
    dec si
    mov di, si
    inc di
    push ds
    push es
    pop ds                    ; DS=0 so source buffer is physical 0000:9500
    std
    rep movsb
    cld
    pop ds
insert_store:
    mov bx, [cursor_pos]
    mov di, 0x9500
    add di, bx
    mov al, [temp_char]
    mov [es:di], al
    inc word [content_size]
    inc word [cursor_pos]
    pop di
    pop si
    pop cx
    pop bx
    ret

redraw_editor:
    mov ax, 0x0003
    int 0x10
    ; BIOS video-mode calls are not relied on to preserve segment registers.
    mov ax, cs
    mov ds, ax
    xor ax, ax
    mov es, ax
    cld
    mov si, edit_header
    call print_string
    mov si, [entry_ptr]
    mov cx, 32
redraw_name:
    mov al, [es:si]
    test al, al
    jz redraw_name_done
    push cx
    push si
    call putc
    pop si
    pop cx
    inc si
    loop redraw_name
redraw_name_done:
    mov si, edit_controls
    call print_string
    ; Display buffer, honoring CR/LF and wrapping at 80 columns.
    mov si, 0x9500
    mov cx, [content_size]
    mov byte [display_col], 0
    mov byte [display_row], 5
redraw_chars:
    jcxz place_cursor
    mov al, [es:si]
    inc si
    dec cx
    cmp al, 13
    je redraw_cr
    cmp al, 10
    je redraw_lf
    call putc
    inc byte [display_col]
    cmp byte [display_col], 80
    jb redraw_chars
    mov byte [display_col], 0
    inc byte [display_row]
    jmp redraw_chars
redraw_cr:
    mov al, 13
    call putc
    mov byte [display_col], 0
    jmp redraw_chars
redraw_lf:
    mov al, 10
    call putc
    inc byte [display_row]
    mov byte [display_col], 0
    jmp redraw_chars
place_cursor:
    ; Convert cursor_pos to screen row/column by scanning preceding bytes.
    mov si, 0x9500
    mov cx, [cursor_pos]
    mov byte [cursor_col], 0
    mov byte [cursor_row], 5
cursor_calc:
    jcxz cursor_ready
    mov al, [es:si]
    inc si
    dec cx
    cmp al, 13
    je calc_cr
    cmp al, 10
    je calc_lf
    inc byte [cursor_col]
    cmp byte [cursor_col], 80
    jb cursor_calc
    mov byte [cursor_col], 0
    inc byte [cursor_row]
    jmp cursor_calc
calc_cr:
    mov byte [cursor_col], 0
    jmp cursor_calc
calc_lf:
    mov byte [cursor_col], 0
    inc byte [cursor_row]
    jmp cursor_calc
cursor_ready:
    mov dh, [cursor_row]
    cmp dh, 24
    jbe cursor_row_ok
    mov dh, 24
cursor_row_ok:
    mov dl, [cursor_col]
    mov bh, 0
    mov ah, 2
    int 0x10
    ret

save_file:
    ; Clear unused bytes in buffer before writing exactly one sector.
    mov di, 0x9500
    add di, [content_size]
    mov cx, 512
    sub cx, [content_size]
    xor al, al
clear_buffer:
    jcxz write_file
    mov [es:di], al
    inc di
    loop clear_buffer
write_file:
    mov si, file_dap
    mov ah, 0x43
    mov dl, [drive]
    int 0x13
    jc disk_error
    ; Update selected entry size in the in-memory directory table.
    mov si, [entry_ptr]
    mov ax, [content_size]
    mov [es:si+32], ax
    ; Write both directory sectors back to LBA 9.
    mov si, dir_dap
    mov ah, 0x43
    mov dl, [drive]
    int 0x13
    jc disk_error
    mov ax, 0x0003
    int 0x10
    mov si, saved_message
    call print_string
    call read_app_key
    jmp menu

file_too_large:
    mov ax, 0x0003
    int 0x10
    mov si, large_message
    call print_string
    call read_app_key
    jmp menu

disk_error:
    mov ax, 0x0003
    int 0x10
    mov si, error_message
    call print_string
    call read_app_key
    jmp menu

exit_editor:
    mov ax, 0x0003
    int 0x10

    mov ax, cs
    mov ds, ax

    mov si, exit_debug_message
    call print_string

.wait_key:
    mov ah, 0x00
    int 0x16

    mov ax, cs
    mov ds, ax
    mov si, key_received_message
    call print_string

    ; Restore the original desktop data segment.
    pop ds

    ; Return to the desktop launcher.
    retf

; Direct PS/2 keyboard polling for app input.
; Returns AL=ASCII, or AL=0 and AH=scan code for extended keys.
; Interrupts are disabled only while polling port 0x60, so the BIOS IRQ handler
; cannot consume the scancode first. Previous FLAGS are restored on return.
read_app_key:
    pushf
    cli
.key_wait:
    in al, 0x64
    test al, 1
    jz .key_wait
    in al, 0x60
    test al, 0x80
    jnz .key_wait             ; ignore key-release scancodes
    xor ah, ah
    cmp al, 0x01              ; Esc
    je .esc
    cmp al, 0x1C              ; Enter
    je .enter
    cmp al, 0x0E              ; Backspace
    je .backspace
    cmp al, 0x10              ; QWERTY Q
    je .q
    cmp al, 0x11              ; W
    je .w
    cmp al, 0x1F              ; S
    je .s
    cmp al, 0x19              ; P
    je .p
    cmp al, 0x2E              ; C (Ctrl+S save shortcut is handled separately below)
    je .c
    cmp al, 0x4B              ; Left arrow
    je .extended
    cmp al, 0x4D              ; Right arrow
    je .extended
    cmp al, 0x47              ; Home
    je .extended
    cmp al, 0x4F              ; End
    je .extended
    mov al, 0
    jmp .done
.esc:
    mov al, 27
    jmp .done
.enter:
    mov al, 13
    jmp .done
.backspace:
    mov al, 8
    jmp .done
.q:
    mov al, 'q'
    jmp .done
.w:
    mov al, 'w'
    jmp .done
.s:
    mov al, 's'
    jmp .done
.p:
    mov al, 'p'
    jmp .done
.c:
    mov al, 'c'
    jmp .done
.extended:
    mov ah, al
    xor al, al
.done:
    popf
    ret

print_string:
    lodsb
    test al, al
    jz print_done
    push si
    call putc
    pop si
    jmp print_string
print_done:
    ret
putc:
    ; Preserve loop registers and segments across BIOS teletype output.
    push ax
    push bx
    push cx
    push dx
    push si
    push di
    push ds
    push es
    mov ah, 0x0E
    xor bh, bh
    int 0x10
    pop es
    pop ds
    pop di
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

exit_debug_message db 'EDIT EXIT REACHED! Press a key.', 13, 10, 0
key_received_message db 'KEY RECEIVED!', 13, 10, 0
list_title db 'KIWI OS - TEXT FILES',13,10,'--------------------',13,10,0
list_controls db 13,10,'W/S: Select  ENTER: Edit',13,10,'ESC: Exit',0
no_files db 'No text files found.',13,10,0
edit_header db 'KIWI OS TEXT EDITOR',13,10,'Editing: ',0
edit_controls db 13,10,'Arrows: Move  Backspace: Delete',13,10,'Enter: New line  Ctrl+S: Save  Esc: Back',13,10,13,10,0
saved_message db 'Saved! Press any key.',0
error_message db 'Disk error! Press any key.',0
large_message db 'File is larger than 512 bytes; not opened. Press any key.',0
temp_char db 0

drive db 0
file_count dw 0
selected dw 0
content_size dw 0
cursor_pos dw 0
entry_ptr dw 0
entries times 16 dw 0
display_col db 0
display_row db 0
cursor_col db 0
cursor_row db 0

dir_dap:
    db 0x10, 0
    dw 2
    dw 0x9100
    dw 0
    dq 9
file_dap:
    db 0x10, 0
    dw 1
    dw 0x9500
    dw 0
    dq 21

times 4096-($-$$) db 0
