
bits 16
org 0

files_app:
    ; Keep BIOS keyboard input available to the app.
    cld
    sti
    push ds
    push cs
    pop ds

    ; Get BIOS boot drive number
    push ds
    xor ax, ax
    mov ds, ax
    mov dl, [0x0500]
    mov [cs:drive], dl
    pop ds

    ; Read filesystem directory from disk sector 9
    mov si, table_dap
    mov ah, 0x42
    mov dl, [drive]
    int 0x13
    jc disk_error

    mov ax, 0
    mov es, ax

    ; Collect real directory entries
    mov word [file_count], 0
    mov si, 0x912F
    mov cx, 16

collect:
    cmp byte [es:si], 0
    je collected

    mov bx, [file_count]
    shl bx, 1
    mov [entry_offsets+bx], si
    inc word [file_count]

    add si, 36
    loop collect

collected:
    mov word [selected], 0

list_screen:
    mov ax, 0x0003
    int 0x10

    mov si, title
    call print_string

    cmp word [file_count], 0
    jne list_entries

    mov si, empty_text
    call print_string
    jmp list_keys

list_entries:
    xor bx, bx

list_loop:
    cmp bx, [file_count]
    jae list_keys

    mov al, ' '
    cmp bx, [selected]
    jne marker
    mov al, '>'

marker:
    call putc
    mov al, ' '
    call putc

    mov di, bx
    shl di, 1
    mov si, [entry_offsets+di]
    mov cx, 32

name_loop:
    mov al, [es:si]
    test al, al
    jz name_done

    push si
    call putc
    pop si
    inc si
    loop name_loop

name_done:
    mov al, 13
    call putc
    mov al, 10
    call putc

    inc bx
    jmp list_loop

list_keys:
    mov si, controls
    call print_string

wait_key:
    call read_app_key

    cmp al, 27
    je exit_app

    cmp al, 'w'
    je move_up
    cmp al, 'W'
    je move_up
    cmp al, 's'
    je move_down
    cmp al, 'S'
    je move_down

    cmp al, 13
    je open_selected

    jmp wait_key

move_up:
    cmp word [selected], 0
    je list_screen
    dec word [selected]
    jmp list_screen

move_down:
    mov ax, [selected]
    inc ax
    cmp ax, [file_count]
    jae list_screen
    mov [selected], ax
    jmp list_screen


open_selected:
    cmp word [file_count], 0
    je wait_key

    ; Find selected directory entry
    mov bx, [selected]
    shl bx, 1
    mov si, [entry_offsets+bx]

    ; Check extension .PA using the filename length
    cmp byte [es:si+4], '.'
    je check_short_pa

    cmp byte [es:si+5], '.'
    je check_long_pa

    jmp open_as_text

check_short_pa:
    cmp byte [es:si+5], 'P'
    jne open_as_text
    cmp byte [es:si+6], 'A'
    jne open_as_text
    jmp launch_selected

check_long_pa:
    cmp byte [es:si+6], 'P'
    jne open_as_text
    cmp byte [es:si+7], 'A'
    jne open_as_text
    jmp launch_selected



open_as_text:
    ; Read actual file size and starting sector
    mov ax, [es:si+32]
    cmp ax, 512
    jbe .size_ok
    mov ax, 512

.size_ok:
    mov [content_size], ax

    mov ax, [es:si+34]
    mov [file_dap+8], ax

    ; Read file data into 0000:9200
    mov si, file_dap
    mov ah, 0x42
    mov dl, [drive]
    int 0x13
    jc disk_error

    ; Reset ES so the text viewer reads from 0000:9200
    xor ax, ax
    mov es, ax

    mov ax, 0x0003
    int 0x10

    xor ax, ax
    mov es, ax

    mov si, opened_title
    call print_string

    mov si, 0x9200
    mov cx, [content_size]

show_content:
    jcxz content_done

    mov al, [es:si]
    inc si
    dec cx

    push cx
    push si
    call putc
    pop si
    pop cx

    jmp show_content

content_done:
    mov si, return_text
    call print_string

    call read_app_key
    jmp list_screen

launch_selected:
    ; EDIT.PA should return all the way to the desktop when it exits.
    mov byte [exit_after_child], 0
    cmp byte [es:si], 'E'
    jne .check_done
    cmp byte [es:si+1], 'D'
    jne .check_done
    cmp byte [es:si+2], 'I'
    jne .check_done
    cmp byte [es:si+3], 'T'
    jne .check_done
    cmp byte [es:si+4], '.'
    jne .check_done
    cmp byte [es:si+5], 'P'
    jne .check_done
    cmp byte [es:si+6], 'A'
    jne .check_done
    cmp byte [es:si+7], 0
    jne .check_done
    mov byte [exit_after_child], 1
.check_done:
    ; Calculate how many sectors the app occupies
    mov ax, [es:si+32]
    add ax, 511
    mov cl, 9
    shr ax, cl
    cmp ax, 1
    jae .count_ok
    mov ax, 1

.count_ok:
    mov [app_dap+2], ax

    ; Get the selected app's starting sector
    mov ax, [es:si+34]
    mov [app_dap+8], ax

    ; Load the app
    mov si, app_dap
    mov ah, 0x42
    mov dl, [drive]
    int 0x13
    jc disk_error

    call far [child_ptr]
    cmp byte [exit_after_child], 1
    je exit_app
    jmp list_screen

disk_error:
    mov ax, 0x0003
    int 0x10
    mov si, error_text
    call print_string
    call read_app_key

exit_app:
    mov ax, 0x0013
    int 0x10
    pop ds
    retf

; Direct PS/2 keyboard polling for app input.
; Returns AL=ASCII, or AL=0 and AH=scan code for extended keys.
; Interrupts are disabled only while polling port 0x60, so the BIOS IRQ handler
; cannot consume the scancode first. Previous FLAGS are restored on return.
read_app_key:
    pushf
    cli
.key_wait:
    in al, 0x64
    test al, 1
    jz .key_wait
    in al, 0x60
    test al, 0x80
    jnz .key_wait             ; ignore key-release scancodes
    xor ah, ah
    cmp al, 0x01              ; Esc
    je .esc
    cmp al, 0x1C              ; Enter
    je .enter
    cmp al, 0x0E              ; Backspace
    je .backspace
    cmp al, 0x10              ; QWERTY Q
    je .q
    cmp al, 0x11              ; W
    je .w
    cmp al, 0x1F              ; S
    je .s
    cmp al, 0x2E              ; C (Ctrl+S save shortcut is handled separately below)
    je .c
    cmp al, 0x4B              ; Left arrow
    je .extended
    cmp al, 0x4D              ; Right arrow
    je .extended
    cmp al, 0x47              ; Home
    je .extended
    cmp al, 0x4F              ; End
    je .extended
    mov al, 0
    jmp .done
.esc:
    mov al, 27
    jmp .done
.enter:
    mov al, 13
    jmp .done
.backspace:
    mov al, 8
    jmp .done
.q:
    mov al, 'q'
    jmp .done
.w:
    mov al, 'w'
    jmp .done
.s:
    mov al, 's'
    jmp .done
.c:
    mov al, 'c'
    jmp .done
.extended:
    mov ah, al
    xor al, al
.done:
    popf
    ret

print_string:
    lodsb
    test al, al
    jz print_done
    push si
    call putc
    pop si
    jmp print_string

print_done:
    ret

putc:
    push bx
    mov ah, 0x0E
    xor bh, bh
    int 0x10
    pop bx
    ret

title db 'KIWI OS - FILE MANAGER',13,10
      db '----------------------',13,10
      db 'Select a file:',13,10,13,10,0

controls db 13,10,'W/S: Select   ENTER: Open',13,10
         db 'ESC: Desktop',0

empty_text db 'No files found.',13,10,0
opened_title db 'FILE CONTENTS',13,10
            db '-------------',13,10,13,10,0
return_text db 13,10,13,10,'Press any key to go back.',0
error_text db 'Disk read failed. Press any key.',0

drive db 0
exit_after_child db 0
file_count dw 0
selected dw 0
content_size dw 0
entry_offsets times 16 dw 0

table_dap:
    db 0x10, 0
    dw 1
    dw 0x9100
    dw 0
    dq 9

file_dap:
    db 0x10, 0
    dw 1
    dw 0x9200
    dw 0
    dq 21

app_dap:
    db 0x10, 0
    dw 2
    dw 0x0000
    dw 0x2000
    dq 22

child_ptr:
    dw 0x0000
    dw 0x2000


times 1024-($-$$) db 0
