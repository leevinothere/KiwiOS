bits 16
org 0

; Kiwi Terminal: print(text) and integer math inside print(...).
; Uses the same direct PS/2 keyboard polling approach as the other apps.

terminal:
    cld
    sti
    push ds
    push cs
    pop ds

    mov ax, 0x0003
    int 0x10

    mov si, banner
    call print_string
    jmp new_prompt

new_prompt:
    mov si, prompt
    call print_string
    mov word [line_len], 0

read_line:
    call read_key
    cmp al, 27
    je exit_terminal
    cmp al, 13
    je submit_line
    cmp al, 8
    je erase_char
    test al, al
    jz read_line

    cmp al, 32
    jb read_line
    cmp word [line_len], 60
    jae read_line
    mov bx, [line_len]
    mov [line_buffer+bx], al
    inc word [line_len]
    call putc
    jmp read_line

erase_char:
    cmp word [line_len], 0
    je read_line
    dec word [line_len]
    mov al, 8
    call putc
    mov al, ' '
    call putc
    mov al, 8
    call putc
    jmp read_line

submit_line:
    mov bx, [line_len]
    mov byte [line_buffer+bx], 0
    mov al, 13
    call putc
    mov al, 10
    call putc
    call execute_print
    jmp new_prompt

; Accept exactly print(...). Empty parentheses print an empty line.
execute_print:
    cmp word [line_len], 7
    jb syntax_error

    mov si, line_buffer
    mov di, print_prefix
    mov cx, 6
.prefix_check:
    mov al, [si]
    cmp al, [di]
    jne syntax_error
    inc si
    inc di
    loop .prefix_check

    mov bx, [line_len]
    dec bx
    mov al, [line_buffer+bx]
    cmp al, ')'
    jne syntax_error

    ; If the contents are a numeric expression, evaluate it first.
    ; Ordinary text still prints exactly as before.
    call try_math
    jc .math_done

    ; Print only the characters between print( and ).
    mov si, line_buffer
    add si, 6
    mov cx, [line_len]
    sub cx, 7
    jcxz .printed
.output_loop:
    lodsb
    call putc
    loop .output_loop
.printed:
    mov al, 13
    call putc
    mov al, 10
    call putc
    ret
.math_done:
    ret

; try_math: recognize and evaluate integer expressions inside print(...).
; Supports + - * /, spaces, and normal multiplication/division precedence.
; Returns CF=1 if handled; CF=0 if the contents are ordinary text.
try_math:
    push ax
    push bx
    push cx
    push dx
    push si
    push di

    mov si, line_buffer
    add si, 6                    ; first character inside print(
    mov di, line_buffer
    mov bx, [line_len]
    add di, bx
    dec di                       ; points at closing ')'
    xor cx, cx                   ; operator count
.scan:
    cmp si, di
    jae .scan_done
    mov al, [si]
    cmp al, '0'
    jb .scan_not_digit
    cmp al, '9'
    jbe .scan_next
.scan_not_digit:
    cmp al, ' '
    je .scan_next
    cmp al, '+'
    je .scan_operator
    cmp al, '-'
    je .scan_operator
    cmp al, '*'
    je .scan_operator
    cmp al, '/'
    je .scan_operator
    jmp .not_math
.scan_operator:
    inc cx
.scan_next:
    inc si
    jmp .scan
.scan_done:
    cmp cx, 0
    je .not_math                ; print(123) remains ordinary text

    ; Start evaluating the first number as the current term.
    mov si, line_buffer
    add si, 6
    mov di, line_buffer
    mov bx, [line_len]
    add di, bx
    dec di
    call parse_math_number
    jc .math_error
    mov [math_term], ax
    mov word [math_total], 0
    mov word [math_sign], 1

.next_operator:
    call skip_math_spaces
    cmp si, di
    jae .finish_math
    mov al, [si]
    inc si
    mov [math_op], al
    call parse_math_number
    jc .math_error
    mov bx, ax                    ; next number
    mov al, [math_op]
    cmp al, '*'
    je .multiply
    cmp al, '/'
    je .divide

    ; + or -: commit the previous signed term, then begin a new term.
    mov ax, [math_term]
    imul word [math_sign]
    add [math_total], ax
    mov word [math_sign], 1
    cmp byte [math_op], '-'
    jne .new_term
    mov word [math_sign], -1
.new_term:
    mov [math_term], bx
    jmp .next_operator
.multiply:
    mov ax, [math_term]
    mul bx
    mov [math_term], ax
    jmp .next_operator
.divide:
    cmp bx, 0
    je .math_error
    mov ax, [math_term]
    xor dx, dx
    div bx
    mov [math_term], ax
    jmp .next_operator

.finish_math:
    mov ax, [math_term]
    imul word [math_sign]
    add ax, [math_total]
    call print_signed_number
    mov al, 13
    call putc
    mov al, 10
    call putc
    stc
    jmp .return
.math_error:
    mov si, math_error_message
    call print_string
    stc
    jmp .return
.not_math:
    clc
.return:
    pop di
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ; Restore the status result after POP instructions (which do not change flags).
    ret

; Parse a non-negative decimal integer at SI, stopping at the next operator.
; DI is the exclusive end pointer. Returns AX=value, CF=1 if no digits.
parse_math_number:
    call skip_math_spaces
    xor bx, bx
    xor dx, dx
.digit_loop:
    cmp si, di
    jae .number_done
    mov al, [si]
    cmp al, '0'
    jb .number_done
    cmp al, '9'
    ja .number_done
    sub al, '0'
    xor ah, ah
    push ax
    mov ax, bx
    mov cx, 10
    mul cx
    mov bx, ax
    pop ax
    add bx, ax
    inc si
    inc dx
    jmp .digit_loop
.number_done:
    cmp dx, 0
    je .no_number
    mov ax, bx
    clc
    ret
.no_number:
    stc
    ret

skip_math_spaces:
.skip:
    cmp si, di
    jae .done
    cmp byte [si], ' '
    jne .done
    inc si
    jmp .skip
.done:
    ret

; Print signed AX as decimal without leading zeroes.
print_signed_number:
    push ax
    push bx
    push cx
    push dx
    test ax, ax
    jns .positive
    mov al, '-'
    call putc
    pop dx
    pop cx
    pop bx
    pop ax
    neg ax
    push ax
    push bx
    push cx
    push dx
.positive:
    xor cx, cx
    mov bx, 10
    cmp ax, 0
    jne .convert
    mov al, '0'
    call putc
    jmp .print_done
.convert:
    xor dx, dx
    div bx
    push dx
    inc cx
    test ax, ax
    jnz .convert
.emit:
    pop dx
    mov al, dl
    add al, '0'
    call putc
    loop .emit
.print_done:
    pop dx
    pop cx
    pop bx
    pop ax
    ret

syntax_error:
    mov si, syntax_message
    call print_string
    ret

exit_terminal:
    mov ax, 0x0013
    int 0x10
    pop ds
    retf

print_string:
    lodsb
    test al, al
    jz .done
    call putc
    jmp print_string
.done:
    ret

putc:
    push bx
    mov ah, 0x0E
    xor bh, bh
    int 0x10
    pop bx
    ret

; Returns AL=ASCII, AL=13 Enter, AL=8 Backspace, AL=27 Esc.
; Shift state supports uppercase letters, quotes, and parentheses.
read_key:
    push bx
    push dx
    pushf
    cli
.poll:
    in al, 0x64
    test al, 1
    jz .poll
    in al, 0x60

    cmp al, 0xAA             ; left Shift released
    je .shift_off
    cmp al, 0xB6             ; right Shift released
    je .shift_off
    test al, 0x80
    jnz .poll                ; ignore other key releases
    cmp al, 0x2A             ; left Shift pressed
    je .shift_on
    cmp al, 0x36             ; right Shift pressed
    je .shift_on
    cmp al, 0x01
    je .escape
    cmp al, 0x1C
    je .enter
    cmp al, 0x0E
    je .backspace

    xor ah, ah
    mov bx, ax
    cmp byte [shift_down], 0
    jne .shifted
    mov al, [keymap+bx]
    jmp .return
.shifted:
    mov al, [shiftmap+bx]
    jmp .return
.shift_on:
    mov byte [shift_down], 1
    jmp .poll
.shift_off:
    mov byte [shift_down], 0
    jmp .poll
.escape:
    mov al, 27
    jmp .return
.enter:
    mov al, 13
    jmp .return
.backspace:
    mov al, 8
.return:
    popf
    pop dx
    pop bx
    ret

banner db 'KIWI TERMINAL v1.0',13,10
       db 'Use print(text) to print text.',13,10
       db 'Press ESC to return to the desktop.',13,10,13,10,0
prompt db '>>> ',0
syntax_message db 'SyntaxError: use print(text)',13,10,0
print_prefix db 'print('
line_len dw 0
line_buffer times 64 db 0
shift_down db 0
math_total dw 0
math_term dw 0
math_sign dw 1
math_op db 0
math_error_message db 'MathError: invalid expression or division by zero',13,10,0

keymap:
    db 0x00, 0x00, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x30, 0x2D, 0x3D, 0x08, 0x09
    db 0x71, 0x77, 0x65, 0x72, 0x74, 0x79, 0x75, 0x69, 0x6F, 0x70, 0x5B, 0x5D, 0x0D, 0x00, 0x61, 0x73
    db 0x64, 0x66, 0x67, 0x68, 0x6A, 0x6B, 0x6C, 0x3B, 0x27, 0x60, 0x00, 0x5C, 0x7A, 0x78, 0x63, 0x76
    db 0x62, 0x6E, 0x6D, 0x2C, 0x2E, 0x2F, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
shiftmap:
    db 0x00, 0x00, 0x21, 0x40, 0x23, 0x24, 0x25, 0x5E, 0x26, 0x2A, 0x28, 0x29, 0x5F, 0x2B, 0x08, 0x09
    db 0x51, 0x57, 0x45, 0x52, 0x54, 0x59, 0x55, 0x49, 0x4F, 0x50, 0x7B, 0x7D, 0x0D, 0x00, 0x41, 0x53
    db 0x44, 0x46, 0x47, 0x48, 0x4A, 0x4B, 0x4C, 0x3A, 0x22, 0x7E, 0x00, 0x7C, 0x5A, 0x58, 0x43, 0x56
    db 0x42, 0x4E, 0x4D, 0x3C, 0x3E, 0x3F, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

 times 4096-($-$$) db 0
