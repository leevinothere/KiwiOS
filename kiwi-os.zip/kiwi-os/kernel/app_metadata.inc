; Kiwi OS app metadata catalog.
; Record format (9 bytes):
;   db X, Y, APP_TYPE
;   dw ICON_BITMAP, DISPLAY_NAME, EXECUTABLE_FILENAME
; APP_TYPE 1 = application. Strings are zero-terminated.
; ICON_BITMAP points to a 16x16, 256-byte VGA palette-index bitmap.
; A zero X byte ends the catalog.
app_metadata:
    db 80, 40, 1
    dw files_icon_bitmap, files_app_name, files_app_filename

    db 120, 40, 1
    dw edit_icon_bitmap, edit_app_name, edit_app_filename

    db 160, 40, 1
    dw terminal_icon_bitmap, terminal_app_name, terminal_app_filename

    db 0, 0, 0
    dw 0, 0, 0

files_app_name db 'Files', 0
files_app_filename db 'FILES.PA', 0

edit_app_name db 'EDIT', 0
edit_app_filename db 'EDIT.PA', 0

terminal_app_name db 'Terminal', 0
terminal_app_filename db 'TERMINAL.PA', 0
