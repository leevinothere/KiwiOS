
bits 16
org 0

filesystem_magic db "KIWI"
filesystem_version db 1
filesystem_sector_size dw 512
filesystem_filetable_sector dw 9
filesystem_max_files dw 16

file_entry:
    filename times 32 db 0
    size dw 0
    start_sector dw 0

file_table:
    ; File 1: HELLO.TXT
    db "HELLO.TXT"
    times 23 db 0
    dw 19
    dw 21

    ; File 2: FILES.PA
    db "FILES.PA"
    times 24 db 0
    dw 1024
    dw 22

    ; File 3: EDIT.PA
    db "EDIT.PA"
    times 25 db 0
    dw 4096
    dw 24

    ; File 4: TERMINAL.PA
    db "TERMINAL.PA"
    times 21 db 0
    dw 4096
    dw 32

    ; BACKGROUND.BMP is a hidden system resource stored at disk LBA 40.
    ; Do not expose it as a normal file: opening raw BMP bytes in the text
    ; viewer would display binary image data and look like screen corruption.
    ; The following zero entry ends the visible directory after the user files.
    times 12 * 36 db 0

; File table occupies the first two sectors
times 1024-($-$$) db 0

; HELLO.TXT starts at disk sector 21
times 12*512-($-$$) db 0
hello_data:
    db "Welcome to Kiwi OS!"

; FILES.PA starts at disk sector 22
times 13*512-($-$$) db 0
incbin "kernel/files.pa"

; EDIT.PA starts at disk sector 24
times 15*512-($-$$) db 0
incbin "kernel/edit.pa"

; TERMINAL.PA starts at absolute disk sector 32 (filesystem-relative sector 23)
times 23*512-($-$$) db 0
incbin "kernel/terminal.pa"

; BACKGROUND.BMP starts at absolute disk sector 40.
times 31*512-($-$$) db 0
incbin "background.bmp"
; BMP occupies 128 sectors; end the filesystem image at absolute sector 168.
times 159*512-($-$$) db 0