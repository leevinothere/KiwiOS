
bits 16
org 0x8000

start:
    ; Set a known real-mode stack before calling apps. The BIOS does not
    ; guarantee a useful SS:SP, and nested app calls can otherwise corrupt
    ; return addresses so keyboard loops and Esc appear to stop working.
    cli
    xor ax, ax
    mov ss, ax
    mov sp, 0x7C00
    mov ds, ax
    cld
    sti

    ; Graphics mode 320x200
    mov ax, 0x0013
    int 0x10

    ; Initialize the PS/2 mouse (works without a DOS mouse driver)
    call init_mouse

    ; VGA memory
    mov ax, 0xA000
    mov es, ax

    ; Load and draw the real BACKGROUND.BMP image file. Keep a green fallback
    ; if the disk read fails, so a missing image never prevents the OS booting.
    call load_background
    jc .background_fallback
    call draw_background
    jmp .background_ready
.background_fallback:
    mov ax, 0A000h
    mov es, ax
    xor di, di
    mov al, 2
    mov cx, 64000
    rep stosb
.background_ready:

    ; Initialize welcome screen
    mov word [cursor_x], 160
    mov word [cursor_y], 100
    call load_font
    call welcome_screen

    ; Restore the real wallpaper after the welcome screen
    call load_background
    jc .desktop_fallback
    call draw_background
    jmp .desktop_bg_ready

.desktop_fallback:
    mov ax, 0A000h
    mov es, ax
    xor di, di
    mov al, 2
    mov cx, 64000
    rep stosb

.desktop_bg_ready:

    ; Reset desktop cursor
    mov word [cursor_x], 160
    mov word [cursor_y], 100

    ; Load directory and draw desktop
    call read_file_table
    call draw_dock
    call draw_desktop_files
    call draw_cursor

    ; Default selection
    mov word [selected_entry], 0x912F
    call select_file_entry

main_loop:
    call erase_cursor
    call poll_mouse
    call read_keyboard
    call draw_cursor
    call delay
    jmp main_loop

; =========================================================
; KIWI OS 1.0 WELCOME SCREEN
; White background, green branding and START button
; =========================================================

; =========================================================
; KIWI OS 1.0 WELCOME SCREEN
; =========================================================

welcome_screen:
    mov byte [welcome_active], 1
    call welcome_draw
    call draw_cursor

.welcome_loop:
    call erase_cursor
    call poll_mouse
    call draw_cursor

    ; Enter key starts Kiwi OS
    mov ah, 01h
    int 16h
    jz .check_mouse

    xor ah, ah
    int 16h
    cmp al, 13
    je .started

.check_mouse:
    cmp byte [welcome_start], 1
    jne .welcome_loop

.started:
    mov byte [welcome_active], 0
    mov byte [welcome_start], 0
    ret


welcome_draw:
    push ax
    push cx
    push dx
    push di

    mov ax, 0A000h
    mov es, ax

    ; White background
    xor di, di
    mov al, 15
    mov cx, 64000
    rep stosb

    ; Green START button
    mov di, 320*130+120
    mov dx, 25

.button_row:
    mov al, 2
    mov cx, 80
    rep stosb
    add di, 240
    dec dx
    jnz .button_row

    pop di
    pop dx
    pop cx
    pop ax

    ; KIWI OS title
    mov word [text_x], 132
    mov word [text_y], 45
    mov byte [ui_text_color], 2
    mov si, welcome_title
    call draw_ui_text

    ; Welcome message
    mov word [text_x], 88
    mov word [text_y], 85
    mov byte [ui_text_color], 0
    mov si, welcome_message
    call draw_ui_text

    ; START button label
    mov word [text_x], 140
    mov word [text_y], 138
    mov byte [ui_text_color], 15
    mov si, welcome_button
    call draw_ui_text

    ; Version
    mov word [text_x], 136
    mov word [text_y], 175
    mov byte [ui_text_color], 8
    mov si, welcome_version
    call draw_ui_text

    ret


; Draw a null-terminated string.
; DS:SI = text, text_x/text_y = position.
; ui_text_color = VGA palette index.

draw_ui_text:
    push ax
    push bx
    push cx
    push dx
    push si
    push di

.next_char:
    lodsb
    test al, al
    jz .done

    xor ah, ah
    mov bx, ax
    shl bx, 1
    shl bx, 1
    shl bx, 1

    mov byte [glyph_row_number], 0

.row:
    mov al, [fs:bx]
    inc bx
    mov [glyph_row], al

    mov ax, [text_y]
    mov dx, 320
    mul dx
    add ax, [text_x]
    mov di, ax

    mov al, [glyph_row]
    mov cx, 8

.pixel:
    test al, 80h
    jz .transparent

    mov dl, [ui_text_color]
    mov [es:di], dl

.transparent:
    inc di
    shl al, 1
    loop .pixel

    inc word [text_y]
    inc byte [glyph_row_number]

    cmp byte [glyph_row_number], 8
    jb .row

    sub word [text_y], 8
    add word [text_x], 8
    jmp .next_char

.done:
    pop di
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

.button_row:
    mov al, 2
    mov cx, 80
    rep stosb
    add di, 240
    dec dx
    jnz .button_row

    pop di
    pop cx
    pop ax
    ret

; =========================================================
; PS/2 mouse — polling, so WASD keyboard controls remain intact
; =========================================================

init_mouse:
    ; Enable the controller's auxiliary (mouse) port.
    call wait_input_empty
    jc .done
    mov al, 0A8h
    out 064h, al

    ; Reset mouse settings, then enable movement packets.
    mov al, 0F6h
    call mouse_send
    jc .done
    mov al, 0F4h
    call mouse_send
    jc .done

    mov byte [mouse_enabled], 1
.done:
    ret

; Wait until the PS/2 controller can accept a command/data byte.
; Carry set means the bounded wait timed out.
wait_input_empty:
    mov cx, 0FFFFh
.wait:
    in al, 064h
    test al, 02h
    jz .ready
    loop .wait
    stc
    ret
.ready:
    clc
    ret

; Send AL as a mouse command and wait for the mouse's 0FAh ACK.
mouse_send:
    push ax
    call wait_input_empty
    jc .failed
    mov al, 0D4h
    out 064h, al
    call wait_input_empty
    jc .failed
    pop ax
    out 060h, al
    call mouse_wait_ack
    ret
.failed:
    pop ax
    stc
    ret

mouse_wait_ack:
    mov cx, 0FFFFh
.wait:
    in al, 064h
    test al, 01h
    jz .again
    test al, 20h             ; bit 5 = data came from the mouse
    jz .again                ; leave keyboard data for BIOS INT 16h
    in al, 060h
    cmp al, 0FAh
    je .ack
.again:
    loop .wait
    stc
    ret
.ack:
    clc
    ret

; Read one available mouse byte per frame. Keyboard bytes are left alone.
poll_mouse:
    push ax
    push bx
    push dx

    cmp byte [mouse_enabled], 1
    jne .done
    in al, 064h
    test al, 01h
    jz .done
    test al, 20h
    jz .done
    in al, 060h

    mov bl, [mouse_cycle]
    cmp bl, 0
    je .first
    cmp bl, 1
    je .second

    mov [mouse_packet+2], al
    mov byte [mouse_cycle], 0
    call apply_mouse_packet
    jmp .done

.first:
    test al, 08h             ; packet byte 1 must have the always-set bit
    jz .done
    mov [mouse_packet], al
    mov byte [mouse_cycle], 1
    jmp .done

.second:
    mov [mouse_packet+1], al
    mov byte [mouse_cycle], 2
.done:
    pop dx
    pop bx
    pop ax
    ret

apply_mouse_packet:
    ; Ignore packets reporting X/Y overflow.
    test byte [mouse_packet], 0C0h
    jnz .done

    ; X is a signed relative movement.
    mov al, [mouse_packet+1]
    cbw
    add [cursor_x], ax

    ; PS/2 positive Y means up, so subtract it from screen Y.
    mov al, [mouse_packet+2]
    cbw
    sub [cursor_y], ax

    ; Keep the cursor within the 320x200 screen.
    cmp word [cursor_x], 0
    jge .x_min_ok
    mov word [cursor_x], 0
.x_min_ok:
    cmp word [cursor_x], 319
    jle .x_max_ok
    mov word [cursor_x], 319
.x_max_ok:
    cmp word [cursor_y], 0
    jge .y_min_ok
    mov word [cursor_y], 0
.y_min_ok:
    cmp word [cursor_y], 199
    jle .check_click
    mov word [cursor_y], 199

.check_click:
    ; Detect a new left-button press (button bit 0 changes 0 -> 1).
    mov al, [mouse_packet]
    and al, 1
    mov ah, [mouse_buttons_prev]
    mov [mouse_buttons_prev], al
    test al, 1
    jz .done
    test ah, 1
    jnz .done

    ; Welcome screen handles clicks separately
    cmp byte [welcome_active], 1
    jne .desktop_click

    cmp word [cursor_x], 120
    jb .done
    cmp word [cursor_x], 199
    ja .done
    cmp word [cursor_y], 130
    jb .done
    cmp word [cursor_y], 154
    ja .done

    mov byte [welcome_start], 1
    jmp .done

.desktop_click:
    call hit_test_desktop_file
    jc .done
    call select_file_entry
    call open_selected_file
.done:
    ret


; =========================================================
; Keyboard
; =========================================================

read_keyboard:
    mov ah, 0x01
    int 0x16
    jz .done

    mov ah, 0x00
    int 0x16

    cmp al, 'w'
    je .up
    cmp al, 's'
    je .down
    cmp al, 'a'
    je .left
    cmp al, 'd'
    je .right
    cmp al, 'e'
    je .open
    cmp al, 'r'
    je .refresh
    cmp al, 'f'
    je .files
    jmp .done

.open:
    call open_selected_file
    jmp .done

.refresh:
    call refresh_active_app
    jmp .done

.files:
    call open_selected_file
    jmp .done

.up:
    cmp word [cursor_y], 0
    je .done
    dec word [cursor_y]
    jmp .done

.down:
    cmp word [cursor_y], 199
    je .done
    inc word [cursor_y]
    jmp .done

.left:
    cmp word [cursor_x], 0
    je .done
    dec word [cursor_x]
    jmp .done

.right:
    cmp word [cursor_x], 319
    je .done
    inc word [cursor_x]

.done:
    ret

; =========================================================
; Cursor — unchanged
; =========================================================

draw_cursor:
    mov ax, [cursor_y]
    mov bx, 320
    mul bx
    add ax, [cursor_x]
    mov di, ax

    mov al, [es:di]
    mov [old_color1], al
    mov al, 0
    stosb

    add di, 319
    mov al, [es:di]
    mov [old_color2], al
    mov al, 0
    stosb
    stosb

    add di, 318
    mov al, [es:di]
    mov [old_color3], al
    mov al, 0
    stosb

    mov al, [es:di]
    mov [old_color4], al
    mov al, 0
    stosb

    mov al, [es:di]
    mov [old_color5], al
    mov al, 0
    stosb
    ret


erase_cursor:
    mov ax, [cursor_y]
    mov bx, 320
    mul bx
    add ax, [cursor_x]
    mov di, ax

    mov al, [old_color1]
    stosb

    add di, 319
    mov al, [old_color2]
    stosb
    stosb

    add di, 318
    mov al, [old_color3]
    stosb
    mov al, [old_color4]
    stosb
    mov al, [old_color5]
    stosb
    ret


; =========================================================
; Real desktop wallpaper: BACKGROUND.BMP (320x200, 8-bit indexed BMP)
; The BMP is stored at disk LBA 40 and loaded to 3000:0000.
; First 16 palette entries match VGA UI colors; the image uses 16..255.
; =========================================================

load_background:
    ; Read 127 sectors, then the final sector. This avoids BIOS 127-sector
    ; limits and keeps the 64 KiB destination buffer within 3000:0000..FFFF.
    mov si, background_dap
    mov ah, 42h
    mov dl, [0500h]
    int 13h
    jc .failed

    mov word [background_dap+2], 1
    mov word [background_dap+4], 0FE00h
    mov dword [background_dap+8], 167
    mov dword [background_dap+12], 0
    mov si, background_dap
    mov ah, 42h
    mov dl, [0500h]
    int 13h
    jc .failed

    ; Install the 256-color BMP palette in the VGA DAC.
    push ds
    mov ax, 3000h
    mov ds, ax
    mov si, 36h
    mov dx, 03C8h
    xor al, al
    out dx, al
    mov dx, 03C9h
    mov cx, 256
.palette_loop:
    mov al, [si+2]       ; BMP red
    shr al, 2            ; VGA DAC uses six-bit channels
    out dx, al
    mov al, [si+1]       ; green
    shr al, 2
    out dx, al
    mov al, [si]         ; blue
    shr al, 2
    out dx, al
    add si, 4
    loop .palette_loop
    pop ds
    clc
    ret
.failed:
    stc
    ret

draw_background:
    push ds
    push si
    push di
    push cx
    mov ax, 3000h
    mov ds, ax
    mov si, 0436h        ; 14-byte BMP header + 40-byte DIB + 1024-byte palette
    mov ax, 0A000h
    mov es, ax
    xor di, di
    mov cx, 32000        ; 64,000 pixels, two per word
    rep movsw
    xor ax, ax
    mov ds, ax
    pop cx
    pop di
    pop si
    pop ds
    ; Restore the OS's expected data segment and VGA destination segment.
    xor ax, ax
    mov ds, ax
    mov ax, 0A000h
    mov es, ax
    ret

; =========================================================
; Delay
; =========================================================

delay:
    mov cx, 0FFFFh

.wait:
    loop .wait
    ret

refresh_active_app:
    cmp byte [window_open], 1
    jne .done

    call draw_window

    mov bx, [file_start_sector]
    call read_sector

    mov ax, 0xA000
    mov es, ax
    call draw_file_text

.done:
    ret

; =========================================================
; Dock
; =========================================================

draw_dock:
    mov ax, 180
    mov bx, 320
    mul bx
    mov di, ax
    mov al, 0
    mov dx, 20

.dock_loop:
    mov cx, 320
    rep stosb
    dec dx
    jnz .dock_loop
    ret


; =========================================================
; Filesystem-driven desktop
; The directory at 912F contains 16 entries of 36 bytes each.
; Metadata supplies an icon only; the filesystem entry is the actual file.
; =========================================================

draw_desktop_files:
    push ax
    push bx
    push cx
    push dx
    push si
    push di
    mov si, 0x912F
    mov byte [desktop_index], 0
.next_entry:
    cmp byte [si], 0
    je .done
    mov [selected_entry], si
    call select_file_entry
    call desktop_position
    call find_metadata_icon
    jc .generic_icon
    call draw_bitmap_icon
    jmp .next
.generic_icon:
    call draw_generic_file_icon
.next:
    add si, 36
    inc byte [desktop_index]
    cmp byte [desktop_index], 16
    jb .next_entry
.done:
    pop di
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

; Set icon X/Y from the zero-based desktop_index (7 columns, 36px spacing).
desktop_position:
    xor ax, ax
    mov al, [desktop_index]
    xor dx, dx
    mov bx, 7
    div bl                     ; AL=row? 8-bit DIV: quotient in AL, remainder in AH
    ; We need column = index % 7 and row = index / 7.
    mov [desktop_row], al
    mov [desktop_col], ah
    xor ax, ax
    mov al, [desktop_col]
    mov bl, 36
    mul bl
    add al, 40
    mov [app_icon_x], al
    xor ax, ax
    mov al, [desktop_row]
    mov bl, 40
    mul bl
    add al, 40
    mov [app_icon_y], al
    ret

; Find metadata icon matching selected filesystem filename.
; Returns CF=0 and app_icon_data on match; CF=1 if generic file icon is needed.
find_metadata_icon:
    push ax
    push bx
    push cx
    push dx
    push si
    push di
    mov si, app_metadata
.meta_next:
    cmp byte [si], 0
    je .not_found
    mov di, [si+7]             ; metadata executable filename pointer
    mov bx, [selected_entry]   ; actual directory entry filename
    mov cx, 32
.compare:
    mov al, [bx]
    cmp al, [di]
    jne .different
    test al, al
    jz .match
    inc bx
    inc di
    loop .compare
.different:
    add si, 9
    jmp .meta_next
.match:
    mov bx, [si+3]             ; icon bitmap pointer
    mov [app_icon_data], bx
    clc
    jmp .finish
.not_found:
    stc
.finish:
    pop di
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

; Draw a 16x16 bitmap from app_icon_data at app_icon_x/app_icon_y.
; Each byte is a VGA palette index; palette index 2 is transparent.
draw_bitmap_icon:
    push ax
    push bx
    push cx
    push dx
    push si
    push di

    mov ax, 0A000h
    mov es, ax
    mov si, [app_icon_data]

    xor ax, ax
    mov al, [app_icon_y]
    mov bx, 320
    mul bx
    xor bx, bx
    mov bl, [app_icon_x]
    add ax, bx
    mov di, ax

    mov dx, 16
.row:
    push dx
    mov cx, 16
.pixel:
    lodsb
    cmp al, 2
    je .transparent
    stosb
    jmp .next_pixel
.transparent:
    inc di
.next_pixel:
    loop .pixel
    add di, 304             ; finish the 320-byte screen row
    pop dx
    dec dx
    jnz .row

    pop di
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret


; Generic document icon for filesystem entries without an app-specific icon.
draw_generic_file_icon:
    push ax
    push bx
    push cx
    push dx
    push di
    mov ax, 0A000h
    mov es, ax
    xor ax, ax
    mov al, [app_icon_y]
    mov bx, 320
    mul bx
    xor bx, bx
    mov bl, [app_icon_x]
    add ax, bx
    mov di, ax
    mov dx, 16
.row:
    mov cx, 12
    mov al, 15
    rep stosb
    add di, 308
    dec dx
    jnz .row
    pop di
    pop dx
    pop cx
    pop bx
    pop ax
    ret

; Map the cursor to an icon cell. CF=0 when inside a visible icon.
hit_test_desktop_file:
    push ax
    push bx
    push dx
    mov ax, [cursor_x]
    cmp ax, 40
    jb .miss
    sub ax, 40
    xor dx, dx
    mov bx, 36
    div bx
    cmp dx, 16                 ; only the icon itself, not empty cell space
    jae .miss
    cmp ax, 7
    jae .miss
    mov [desktop_col], al
    mov ax, [cursor_y]
    cmp ax, 40
    jb .miss
    sub ax, 40
    xor dx, dx
    mov bx, 40
    div bx
    cmp dx, 16
    jae .miss
    cmp ax, 3
    jae .miss
    ; index = row*7 + col; only 16 filesystem slots exist
    mov bx, 7
    mul bx
    xor bx, bx
    mov bl, [desktop_col]
    add ax, bx
    cmp ax, 16
    jae .miss
    mov bx, 36
    mul bx
    add ax, 0x912F
    mov [selected_entry], ax
    clc
    jmp .finish
.miss:
    stc
.finish:
    pop dx
    pop bx
    pop ax
    ret

; Read size and starting sector from the selected 36-byte filesystem entry.
select_file_entry:
    mov si, [selected_entry]
    mov ax, [si+32]
    mov [file_size], ax
    mov ax, [si+34]
    mov [file_start_sector], ax
    ret

open_selected_file:
    ; .PA files are executable entries; everything else opens as file content.
    mov si, [selected_entry]
    mov di, si
    add di, 0
.scan_extension:
    cmp byte [di], 0
    je .open_text
    cmp byte [di], '.'
    je .check_pa
    inc di
    jmp .scan_extension
.check_pa:
    cmp byte [di+1], 'P'
    jne .open_text
    cmp byte [di+2], 'A'
    jne .open_text
    cmp byte [di+3], 0
    jne .open_text
    call launch_selected_app
    ret
.open_text:
    call open_file
    ret

; =========================================================
; File window
; =========================================================

draw_window:
    mov ax, 0xA000
    mov es, ax

    mov ax, 60
    mov bx, 320
    mul bx
    add ax, 120
    mov di, ax

    mov al, 15
    mov dx, 70

.window_loop:
    mov cx, 80
    rep stosb
    add di, 240
    dec dx
    jnz .window_loop
    ret


; =========================================================
; Open file
; =========================================================

open_file:
    mov byte [window_open], 1
    call draw_window
    mov bx, [file_start_sector]
    call read_sector
    mov ax, 0xA000
    mov es, ax
    call draw_file_text
    ret

; Load and execute the selected .PA entry using its real directory metadata.
launch_selected_app:
    mov ax, [file_size]
    add ax, 511
    mov cl, 9
    shr ax, cl                 ; number of 512-byte sectors, rounded up
    cmp ax, 8
    jbe .count_ok
    mov ax, 8                  ; 4096-byte maximum for this simple loader
.count_ok:
    mov [app_dap+2], ax
    mov ax, [file_start_sector]
    mov [app_dap+8], ax
    mov si, app_dap
    mov ah, 0x42
    mov dl, [0x0500]
    int 0x13
    jc .failed

    ; BIOS keyboard input (INT 16h) needs hardware interrupts enabled.
    ; Reassert this at the app boundary in case a BIOS disk routine changed IF.
    cld
    sti
    call far [app_far_ptr]

    ; Restore graphics mode after the app returns.
    mov ax, 0x0013
    int 0x10

    ; Restore OS segments and redraw filesystem entries.
    xor ax, ax
    mov ds, ax
    mov ds, ax
    mov ax, 0x7000
    mov fs, ax
    mov ax, 0xA000
    mov es, ax
    ; Text-mode apps reset the VGA DAC palette. Reload the BMP resource so
    ; the wallpaper palette is restored as well as its pixels on app return.
    call load_background
    jc .restore_green_background
    call draw_background
    jmp .background_restored
.restore_green_background:
    xor di, di
    mov al, 2
    mov cx, 64000
    rep stosb
.background_restored:
    call draw_dock
    call draw_desktop_files
    call draw_cursor
    ret
.failed:
    xor ax, ax
    mov ds, ax
    mov ax, 0xA000
    mov es, ax
    ret

app_far_ptr:
    dw 0x0000
    dw 0x1000

background_dap:
    db 0x10
    db 0
    dw 127
    dw 0x0000
    dw 0x3000
    dq 40

app_dap:
    db 0x10
    db 0
    dw 1
    dw 0x0000
    dw 0x1000
    dq 22


; =========================================================
; Read one sector
; BX = LBA
; Data destination = 0000:9000
; =========================================================

read_sector:
    mov [dap+8], bx

    mov si, dap
    mov ah, 0x42
    mov dl, [0x0500]
    int 0x13
    ret


; =========================================================
; Disk Address Packet for file data
; =========================================================

dap:
    db 0x10
    db 0
    dw 1
    dw 0x9000
    dw 0
    dq 0


; =========================================================
; Load BIOS 8x8 font into 7000:0000
; =========================================================

load_font:
    mov ax, 0x1130
    mov bh, 1
    int 0x10

    ; BIOS returns font address in ES:BP
    push ds
    push si
    push di
    push cx
    push ax

    mov ax, es
    mov ds, ax
    mov si, bp

    mov ax, 0x7000
    mov es, ax
    xor di, di

    mov cx, 2048

.copy:
    mov al, [ds:si]
    mov [es:di], al
    inc si
    inc di
    loop .copy

    pop ax
    pop cx
    pop di
    pop si
    pop ds

    ; Restore data segment
    xor ax, ax
    mov ds, ax

    ; Set font segment
    mov ax, 0x7000
    mov fs, ax

    ; Restore VGA segment
    mov ax, 0xA000
    mov es, ax
    ret


; =========================================================
; Draw text
; Text buffer = 0000:9000
; Font = 7000:0000
; =========================================================

draw_file_text:
    mov si, 0x9000

    mov word [text_x], 125
    mov word [text_y], 65

    mov cx, [file_size]

.next_char:
    cmp cx, 0
    je .done

    mov al, [si]
    inc si

    cmp al, 10
    je .newline

    cmp al, 13
    je .return

    cmp al, ' '
    je .space

    ; Character index multiplied by 8
    xor ah, ah
    mov bx, ax
    shl bx, 1
    shl bx, 1
    shl bx, 1

    ; Draw eight rows
    mov byte [glyph_row_number], 0

.row:
    mov al, [fs:bx]
    inc bx
    mov [glyph_row], al

    ; Calculate screen position
    mov ax, [text_y]
    mov dx, 320
    mul dx
    add ax, [text_x]
    mov di, ax

    ; Draw eight pixels
    mov al, [glyph_row]
    mov byte [pixel_count], 8

.pixel:
    test al, 10000000b
    jz .no_pixel

    mov byte [es:di], 0

.no_pixel:
    inc di
    shl al, 1
    dec byte [pixel_count]
    jnz .pixel

    inc word [text_y]
    inc byte [glyph_row_number]

    cmp byte [glyph_row_number], 8
    jb .row

    ; Return to top of character
    sub word [text_y], 8

    ; Advance to next character
    add word [text_x], 8

    ; Wrap text
    cmp word [text_x], 195
    jb .next

    mov word [text_x], 125
    add word [text_y], 10

.next:
    dec cx
    jmp .next_char

.space:
    add word [text_x], 8
    dec cx
    jmp .next_char

.newline:
    mov word [text_x], 125
    add word [text_y], 10
    dec cx
    jmp .next_char

.return:
    mov word [text_x], 125
    dec cx
    jmp .next_char

.done:
    xor ax, ax
    mov ds, ax

    mov ax, 0xA000
    mov es, ax
    ret


; =========================================================
; Read filesystem table from LBA 9
; Destination = 0000:9100
; =========================================================

read_file_table:
    mov si, dap_table
    mov ah, 0x42
    mov dl, [0x0500]
    int 0x13
    ret


; =========================================================
; Filesystem table DAP
; =========================================================

dap_table:
    db 0x10
    db 0
    dw 1
    dw 0x9100
    dw 0
    dq 9


; App catalog is separate from app executable bytes. Bitmap assets are raw
; 16x16 VGA palette-index images; palette index 2 blends with the green desktop.
%include "kernel/app_metadata.inc"
files_icon_bitmap:
    incbin "icons/files.kic"
edit_icon_bitmap:
    incbin "icons/edit.kic"
terminal_icon_bitmap:
    incbin "icons/terminal.kic"

; =========================================================
; Variables
; =========================================================

saved_file_size dw 0
window_open db 0
app_icon_x db 0
app_icon_y db 0
app_icon_data dw 0
desktop_index db 0
desktop_row db 0
desktop_col db 0
selected_entry dw 0x912F

cursor_x dw 160
cursor_y dw 100

mouse_enabled db 0
mouse_cycle db 0
mouse_packet times 3 db 0
mouse_buttons_prev db 0

file_start_sector dw 0
file_size dw 0

text_x dw 125
text_y dw 65

glyph_row db 0
glyph_row_number db 0
pixel_count db 0

old_color db 0
old_color1 db 0
old_color2 db 0
old_color3 db 0
old_color4 db 0
old_color5 db 0

welcome_active db 0
welcome_start db 0
ui_text_color db 0

welcome_title db "KIWI OS", 0
welcome_message db "Welcome to Kiwi OS", 0
welcome_button db "START", 0
welcome_version db "VERSION 1.0", 0

; Pad stage2 to exactly 4096 bytes
times 4096-($-$$) db 0
