KIWI TERMINAL
=============

A new desktop app with one command form:

    print(text)

Examples:
    print(hello)
    print(Kiwi OS is alive!)
    print()

The text inside the parentheses is printed as-is, without quotation marks.
The terminal intentionally does not include help, ver, dir, or other shell commands.
Press Esc to return to the Kiwi OS desktop.

To rebuild from source on the Mac:
    make clean && make && make run

The terminal app is added to the app metadata and filesystem as TERMINAL.PA.
The filesystem image layout remains fixed for the existing files; TERMINAL.PA
starts at absolute disk sector 32 and occupies the following 8 sectors.

Note: the build could not be assembled or boot-tested in this environment
because NASM and QEMU are not installed here. Please rebuild and test in your
existing Mac/QEMU setup.

Math update: print(5+3) prints 8; print(12 * 8) prints 96.
Supported operators: +, -, *, /. Multiplication and division are evaluated before addition and subtraction. Division is integer division. Division by zero shows MathError. Ordinary text such as print(Hello world!) still prints as text.
